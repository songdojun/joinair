package com.example.joinair;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoinairApplicationTests {

	@Test
	void contextLoads() {
		//
	}

}
