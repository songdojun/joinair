package com.example.joinair.dto;
//
//import lombok.Getter;
//import lombok.Setter;
//
//import java.util.Date;
//
//@Getter
//@Setter
//
//public class REVIEW {
//
//    private int Rev_No;             // 리뷰번호
//    private String User_Id;         // UserID
//    private int Pro_Code;           // 상품코드
//    private int Pay_No;             // 결제번호
//    private String Rev_Title;       // 리뷰제목
//    private String Rev_Content;     // 리뷰내용
//    private String Rev_Writer;      // 리뷰작성자
//    private Date Rev_Date;          // 리뷰작성날짜 테스트
//
//}
