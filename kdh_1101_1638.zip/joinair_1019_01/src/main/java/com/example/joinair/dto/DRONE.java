package com.example.joinair.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DRONE {

    private int D_Code;         //드론식별코드
    private int D_Payload;      // 페이로드 용랑
    private int D_Count;            // 수량
    private int D_Size;             //크기
    private int D_Weight;           //무게
    private int D_Speed;           //속도
//수정
//수정

}
