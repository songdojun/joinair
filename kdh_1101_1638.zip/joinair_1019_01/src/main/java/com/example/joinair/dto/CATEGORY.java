package com.example.joinair.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CATEGORY {

    private int Cate_No;
    private String Cate_Name;

}
